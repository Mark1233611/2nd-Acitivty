using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Mark.Models;

namespace Mark.Pages
{
    public class CreateModel : PageModel
    {
        [BindProperty]
        public PersonModel Person { get; set; }


        public void OnGet(string firstname, string lastname, string mi, string address, string age, string contact, string email)
        {

        }


        public ActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            return Redirect("/Index");
        }
    }
}
