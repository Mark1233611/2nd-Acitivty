﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Mark.Models
{
    public class PersonModel
    {
        [Required]
        [StringLength(20)]
        public string Firstname { get; set; }

        [Required]
        [StringLength(20)]
        public string Lastname { get; set; }

        [StringLength(1)]
        public string Mi { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        [Range(18, 60)]
        public int Age { get; set; }

        [StringLength(18)]
        public string Contact { get; set; }

        [Required]
        [StringLength(100)]
        public string Email { get; set; }
    }
}
